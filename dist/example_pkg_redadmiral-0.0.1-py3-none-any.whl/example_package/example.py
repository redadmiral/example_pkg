def add_one(number: float) -> float:
    return number + 1.0
